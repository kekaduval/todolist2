import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-task-list-page',
  templateUrl: './task-list-page.page.html',
  styleUrls: ['./task-list-page.page.scss'],
})
export class TaskListPagePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
