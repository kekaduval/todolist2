import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TaskListPagePage } from './task-list-page.page';

describe('TaskListPagePage', () => {
  let component: TaskListPagePage;
  let fixture: ComponentFixture<TaskListPagePage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TaskListPagePage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TaskListPagePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
