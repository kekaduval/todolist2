import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-task-page',
  templateUrl: './add-task-page.page.html',
  styleUrls: ['./add-task-page.page.scss'],
})
export class AddTaskPagePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
